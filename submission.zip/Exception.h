#ifndef HW4_EXCEPTION_H
#define HW4_EXCEPTION_H

#include <iostream>
#include <exception>
#include <string>
#include <sstream>

class DeckFileNotFound : public std::exception{
public:
    const char * what() const noexcept override
    {
        return "Deck File Error: File not found";
    }
};

class DeckFileFormatError : public std::exception{
    std::string toReturn;
public:
    explicit DeckFileFormatError(std::string line): toReturn("Deck File Error: File format error in line " + line)
    {}
    const char * what() const noexcept override
    {
        return toReturn.c_str();
    }
    ~DeckFileFormatError() override = default;
};

class DeckFileInvalidSize : public std::exception{
public:
    const char * what() const noexcept override
    {
        return "Deck File Error: Deck size is invalid";
    }
};
#endif //HW4_EXCEPTION_H
