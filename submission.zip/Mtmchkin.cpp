#include "Mtmchkin.h"
#include <iostream>
#include <fstream>
#include "Cards/Barfight.h"
#include "Cards/Dragon.h"
#include "Cards/Fairy.h"
#include "Cards/Goblin.h"
#include "Cards/Merchant.h"
#include "Cards/Pitfall.h"
#include "Cards/Treasure.h"
#include "Cards/Vampire.h"
#include "Cards/Gang.h"
#include "Players/Wizard.h"
#include "Players/Rogue.h"
#include "Players/Fighter.h"
#include <string>

using namespace std;

static const int EMPTY_QUEUE=0;
static const int START_OF_GAME_TURNS=0;
static const int START_OF_GAME_ROUNDS=1;

bool Mtmchkin::checkDigit(string word) {
    unsigned int index=0;
    if(word.length()==0){
        return false;
    }
    while(index < word.length()){
        if(!isdigit(word[index])){
            return false;
        }
        index++;
    }
    return true;
}

bool Mtmchkin::checkAlpha(string name)
{
    unsigned int index=0;
    if(name.length()==0){
        return false;
    }
    while(index < name.length()){
        if(isalpha(name[index]) == 0){
            return false;
        }
        index++;
    }
    return true;
}

unique_ptr<Card> Mtmchkin::makeCard(const string& type, const int& line)
{
    if (type == "Fairy") {
        return (unique_ptr<Card> (new Fairy()));
    }
    else if (type == "Vampire") {
        return (unique_ptr<Card> (new Vampire()));
    }
    else if (type == "Treasure") {
        return (unique_ptr<Card> (new Treasure()));
    }
    else if (type == "Pitfall") {
        return (unique_ptr<Card> (new Pitfall()));
    }
    else if (type == "Merchant") {
        return (unique_ptr<Card> (new Merchant()));
    }
    else if (type == "Goblin") {
        return (unique_ptr<Card> (new Goblin()));
    }
    else if (type == "Dragon") {
        return (unique_ptr<Card> (new Dragon()));
    }
    else if (type == "Barfight") {
        return(unique_ptr<Card> (new Barfight()));
    }
    else if (type=="Gang"){
        return (unique_ptr<Card> (new Gang()));
    }
    else {
        throw DeckFileFormatError(to_string(line));
    }
}
bool Mtmchkin::isBattleCard(const string& type)
{
    return (type=="Dragon" || type=="Vampire" || type=="Goblin");
}

vector<unique_ptr<Card>> Mtmchkin::makeCardDeck(const string& fileName)
{
    vector<unique_ptr<Card>> cardsQueue;
    ifstream source(fileName);
    if(!source){
        throw DeckFileNotFound();
    }
    string type;
    int counterLines=1;
    bool isGang = false;
    //Trying to catch exceptions from makeCard to close the file if we catch one.
    try {
        while (getline(source, type)) {
            cardsQueue.push_back(makeCard(type, counterLines));
            isGang = (type == "Gang");
            counterLines++;
            while (isGang && getline(source, type)) {
                isGang = (type != "EndGang");
                if(isGang) {
                    if (isBattleCard(type)) {
                        cardsQueue[cardsQueue.size() - 1]->addMember(makeCard(type, counterLines));
                    } else {
                        source.close();
                        throw DeckFileFormatError(to_string(counterLines));
                    }
                }
                counterLines++;
            }
        }
    }
    catch (DeckFileFormatError &e) {
        source.close();
        throw e;
    }
    source.close();
    if(isGang){
        throw DeckFileFormatError(to_string(counterLines));
    }
    if(cardsQueue.size()<5){
        throw DeckFileInvalidSize();
    }
    return cardsQueue;
}


const int Mtmchkin::getNumberOfPlayers()
{
    printEnterTeamSizeMessage();
    bool flagOfPlayers= false;
    string input;
    int numOfPlayers=0;
    while(!flagOfPlayers){
        getline(cin,input,'\n');
        if(checkDigit(input)){
            //checkDigit make sure input is only a number.
            numOfPlayers= stoi(input);
            if(numOfPlayers>=2 && numOfPlayers<=6){
                flagOfPlayers= true;
            }
        }
        if (!flagOfPlayers) {
            printInvalidTeamSize();
            printEnterTeamSizeMessage();
        }
    }
    return numOfPlayers;
}

bool Mtmchkin::checkIfLegitPlayerType(const string& type)
{
    if(type=="Wizard" || type=="Rogue" || type=="Fighter"){
        return true;
    }
    return false;
}

unique_ptr<Player> Mtmchkin::makePlayer(const string& type,string& name)
{
    try {
        if (type == "Wizard") {
            unique_ptr<Player> player(new Wizard(name));
            return player;
        } else if (type == "Rogue") {
            unique_ptr<Player> player(new Rogue(name));
            return player;
        } else {
            unique_ptr<Player> player(new Fighter(name));
            return player;
        }
    }
    catch (bad_alloc &e) {
        throw e;
    }
}

vector<unique_ptr<Player>> Mtmchkin::makePlayersDeck(const int& numOfPlayers)
{
    vector<unique_ptr<Player>> playersQueue;
    for (int i = 0; i < numOfPlayers;) {
        printInsertPlayerMessage();
        bool flagLegit = false;
        while(!flagLegit){
            string playerName;
            string playerJob;
            getline(cin,playerName,' ');
            getline(cin,playerJob,'\n');
            if(playerName.length()>15|| !checkAlpha(playerName)){
                printInvalidName();
            }
            else if (checkIfLegitPlayerType(playerJob)) {
                try {
                    playersQueue.push_back(makePlayer(playerJob, playerName));
                    flagLegit = true;
                    i++;
                }
                catch (bad_alloc &e) {
                    throw e;
                }
            }
            else{
                printInvalidClass();
            }
        }
    }
    return playersQueue;
}

Mtmchkin::Mtmchkin(const string& fileName)
{
    printStartGameMessage();
    try {
        m_cardsQueue= makeCardDeck(fileName);
        m_activePlayersQueue= makePlayersDeck(getNumberOfPlayers());
        m_round=START_OF_GAME_ROUNDS;
        m_turn=START_OF_GAME_TURNS;
        vector<unique_ptr<Player>> winners;
        vector<unique_ptr<Player>> losers;
        m_winnersPlayersQueue=move(winners);
        m_loserPlayersQueue=move(losers);
    }
    catch (DeckFileFormatError& e) {
        throw e;
    }
    catch (DeckFileNotFound& e){
        throw e;
    }
    catch (DeckFileInvalidSize& e) {
        throw e;
    }
}

void Mtmchkin::printLeaderBoard() const
{
    printLeaderBoardStartMessage();
    int rank=1;
    for (unsigned int j=0; j<m_winnersPlayersQueue.size(); ++j) {
        printPlayerLeaderBoard(rank++, *m_winnersPlayersQueue[j]);
    }

    for (unsigned int j=0; j<m_activePlayersQueue.size(); ++j) {
        printPlayerLeaderBoard(rank++, *m_activePlayersQueue[j]);
    }
    for (unsigned int j=0; j<m_loserPlayersQueue.size(); ++j) {
        printPlayerLeaderBoard(rank++, *m_loserPlayersQueue[m_loserPlayersQueue.size() - j - 1]);
    }
}

bool Mtmchkin::isGameOver() const
{
    return (m_activePlayersQueue.size()==EMPTY_QUEUE);
}

int Mtmchkin::getNumberOfRounds() const
{
    return m_round-1;
}

void Mtmchkin::nextCard()
{
    m_turn=(m_turn+1)%m_cardsQueue.size();

}

void Mtmchkin::moveToCorrectQueue(unsigned int& player)
{
    if(m_activePlayersQueue[player]->gameStatus() == GameStatus::Won){
        m_winnersPlayersQueue.push_back(move(m_activePlayersQueue[player]));
        m_activePlayersQueue.erase(m_activePlayersQueue.begin()+player);
        player--;
    }
    else if(m_activePlayersQueue[player]->gameStatus() == GameStatus::Loss) {
        m_loserPlayersQueue.push_back(move(m_activePlayersQueue[player]));
        m_activePlayersQueue.erase(m_activePlayersQueue.begin() + player);
        player--;
    }
    if(m_activePlayersQueue.size()==EMPTY_QUEUE){
        printGameEndMessage();
    }
}

void Mtmchkin::playRound()
{
    printRoundStartMessage(m_round);
    for(unsigned int position=0; position < m_activePlayersQueue.size(); ++position){
        printTurnStartMessage(m_activePlayersQueue[position]->getName());
        m_cardsQueue[m_turn]->applyEncounter(*m_activePlayersQueue[position]);
        moveToCorrectQueue(position);
        nextCard();
    }
    m_round++;
}
