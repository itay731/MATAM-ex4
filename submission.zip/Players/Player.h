#ifndef MTMCHKIN_PLAYER_H
#define MTMCHKIN_PLAYER_H

#include "../HealthPoints.h"
#include <iostream>
#include <string>
#include <memory>

enum GameStatus{Won,Loss,Active};

static const int MAX_LEVEL=10;
static const int KNOCKEDOUT=0;
static const int DEFAULT_FORCE=5;
static const int DEFAULT_MAX_HP=100;
static const int ILLEGAL=0;
static const int START_LEVEL=1;
static const int DEFAULT_COINS=10;

class Player{

    std::string m_name;
    int m_level;
    int m_force;
    int m_coins;
    HealthPoints m_HP;
protected:
    int getLevel() const;
    int getForce() const;
    const int getHP() const;
    void setNewCoins(int add);
    void setNewHealth(int add);

public:
    explicit Player(std::string name);
    // Copy c'tor
    Player(const Player& player)=default;
    Player& operator=(const Player& player)=default;
    //Return the type of player (Wizard,Rogue,Fighter)
    virtual std::string getType();
    std::string getName() const;
    //return the Name of the Player
    int getCoins() const;
    bool operator==(const Player& player) const;
    void levelUp();
    void buff(int addForce);
    void kill();
    virtual void heal(int addHP);
    void damage(int reduceHP);
    const GameStatus gameStatus() const;
    virtual void addCoins(int treasure);
    bool pay(int payment);
    virtual int getAttackStrength() const;
    virtual std::ostream& printDetails(std::ostream& os) const {return os;};
    friend std::ostream& operator<<(std::ostream& os,const Player& player);
    // d'tor of Base Class
    virtual ~Player()=default;
};


#endif //MTMCHKIN_PLAYER_H
