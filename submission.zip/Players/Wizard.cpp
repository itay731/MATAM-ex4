#include "Wizard.h"
#include "../utilities.h"

using namespace std;

Wizard::Wizard(string name): Player(name)
{}

void Wizard::heal(int addHP)
{
    setNewHealth(2*addHP);
}

string Wizard::getType()
{
    return "Wizard";
}

ostream& Wizard::printDetails(ostream& os) const {
    printPlayerDetails(os,getName(),"Wizard", getLevel(), getForce(),getHP(),getCoins());
    return os;
}

