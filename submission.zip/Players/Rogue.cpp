#include "Rogue.h"
#include "../utilities.h"

using namespace std;

Rogue::Rogue(string name): Player(name)
{}

void Rogue::addCoins(int treasure)
{
    setNewCoins(2*treasure);
}

std::string Rogue::getType()
{
    return "Rogue";
}

ostream& Rogue::printDetails(ostream& os) const {
    printPlayerDetails(os,getName(),"Rogue", getLevel(), getForce(),getHP(),getCoins());
    return os;
}
