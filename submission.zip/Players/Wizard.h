#ifndef HW4_WIZARD_H
#define HW4_WIZARD_H

#include "Player.h"

class  Wizard: public Player
{
public:
    explicit Wizard(std::string name);
    Wizard(const Wizard& goblin) = default;
    Wizard& operator=(const Wizard& other) = default;
    void heal(int addHP) override;
    std::string getType() override;
    std::ostream& printDetails(std::ostream& os) const override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Wizard() override {};
};
#endif //HW4_WIZARD_H
