#include "Player.h"
#include "../utilities.h"

using namespace std;

Player::Player(std::string name)
{
    m_name=name;
    m_level=START_LEVEL;
    m_force=DEFAULT_FORCE;
    m_coins=DEFAULT_COINS;
    HealthPoints hpToSet(DEFAULT_MAX_HP);
    m_HP = hpToSet;
}

std::string Player::getName() const
{
    return m_name;
}

int Player::getLevel() const
{
    return m_level;
}

int Player::getForce() const
{
    return m_force;
}

const int Player::getHP() const
{
    return m_HP.getCurrentHealthPoints();
}

int Player::getCoins() const
{
    return m_coins;
}

bool Player::operator==(const Player& otherPlayer) const
{
    if(m_name==otherPlayer.getName()){
        if(this->m_coins==otherPlayer.getCoins()){
            if(this->m_HP==otherPlayer.getHP()){
                if(this->m_force==otherPlayer.getForce()){
                    if(this->m_level==otherPlayer.getLevel()){
                            return true;
                    }
                }
            }
        }
    }
    return false;
}

void Player::levelUp()
{
    if(m_level<MAX_LEVEL) {
        m_level++;
    }
}

//Never used
std::string Player::getType()
{
    return "Default Player";
}

void Player::buff(const int addForce)
{
    if(addForce+m_force>=ILLEGAL) {
        m_force += addForce;
    }
}

void Player::kill()
{
    m_HP=KNOCKEDOUT;
}

void Player::heal(const int addHP)
{
    if(addHP>ILLEGAL) {
        m_HP+=addHP;
    }
}

void Player::damage(const int reduceHP)
{
    m_HP-=reduceHP;
}

void Player::setNewCoins(int add)
{
    m_coins+=add;
}

void Player::setNewHealth(int add)
{
    m_HP+=add;
}

void Player::addCoins(int treasure)
{
    m_coins += treasure;
}

bool Player::pay(int payment)
{
    if(payment>ILLEGAL) {
        if (m_coins >= payment) {
            m_coins-=payment;
            return true;
        }
    }
    return false;
}

int Player::getAttackStrength() const
{
    return (m_level+m_force);
}

std::ostream& operator<<(std::ostream& os, const Player& player)
{
    player.printDetails(os);
    return os;
}

const GameStatus Player::gameStatus() const
{
    if(m_HP==KNOCKEDOUT){
        return GameStatus::Loss;
    }
    else  if(m_level==MAX_LEVEL){
        return GameStatus::Won;
    }
    return GameStatus::Active;
}
