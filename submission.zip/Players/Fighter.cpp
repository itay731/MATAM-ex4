#include "Fighter.h"
#include "../utilities.h"

using namespace std;

Fighter::Fighter(string name): Player(name)
{}

int Fighter::getAttackStrength() const
{
    return ((getForce()*2)+getLevel());
}

string Fighter::getType()
{
    return "Fighter";
}

std::ostream& Fighter::printDetails(ostream& os) const {
    printPlayerDetails(os,getName(),"Fighter", getLevel(), getForce(),getHP(),getCoins());
    return os;
}
