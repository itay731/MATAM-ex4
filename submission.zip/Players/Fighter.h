#ifndef HW4_FIGHTER_H
#define HW4_FIGHTER_H

#include "Player.h"

class  Fighter: public Player
{
public:
    explicit Fighter(std::string name);
    Fighter(const Fighter& fighter) = default;
    Fighter& operator=(const Fighter& other) = default;
    int getAttackStrength() const override;
    std::string getType() override;
    std::ostream& printDetails(std::ostream& os)const override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Fighter() override {};
};
#endif //HW4_FIGHTER_H
