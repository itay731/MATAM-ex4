#ifndef HW4_ROGUE_H
#define HW4_ROGUE_H

#include "Player.h"

class  Rogue: public Player
{
public:
    explicit Rogue(std::string name);
    Rogue(const Rogue& rogue) = default;
    Rogue& operator=(const Rogue& other) = default;
    void addCoins(int treasure) override;
    std::string getType() override;
    std::ostream& printDetails(std::ostream& os)const override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Rogue() override {};
};

#endif //HW4_ROGUE_H
