#ifndef MTMCHKIN_H_
#define MTMCHKIN_H_

#include <iostream>
#include "Players/Player.h"
#include "Cards/Card.h"
#include <vector>


class Mtmchkin{
    std::vector<std::unique_ptr<Player>> m_activePlayersQueue;
    std::vector<std::unique_ptr<Player>> m_winnersPlayersQueue;
    std::vector<std::unique_ptr<Player>> m_loserPlayersQueue;
    std::vector<std::unique_ptr<Card>> m_cardsQueue;
    int m_round;
    int m_turn;
    //Returns if string is integer.
    static bool checkDigit(std::string word) ;
    //Changes m_turn to next move
    void nextCard();
    static std::unique_ptr<Card> makeCard(const std::string& type, const int& line) ;
    static bool isBattleCard(const std::string& type) ;
    static bool checkAlpha(std::string name);
    static std::vector<std::unique_ptr<Card>> makeCardDeck(const std::string& fileName) ;
    static const int getNumberOfPlayers();
    static bool checkIfLegitPlayerType(const std::string& type);
    static std::unique_ptr<Player> makePlayer(const std::string& type, std::string& name);
    static std::vector<std::unique_ptr<Player>> makePlayersDeck(const int& numOfPlayers) ;
    //If player lost moved to Losers Deck and If player wins move to winners Deck
    //Remove from active players deck
    void moveToCorrectQueue(unsigned int& player);

public:
    
    /*
    * C'tor of Mtmchkin class
    *
    * @param filename - a file which contains the cards of the deck.
    * @return
    *      A new instance of Mtmchkin.
    */
    explicit Mtmchkin(const std::string& fileName);
    
    /*
    * Play the next Round of the game - according to the instruction in the exercise document.
    *
    * @return
    *      void
    */
    // Don't want to let the customer to make copy or assignment of Mtmchkin
    Mtmchkin(const Mtmchkin& mtmchkin) = delete;
    Mtmchkin& operator=(const Mtmchkin& other) = delete;


    void playRound();


    /*
    * Prints the leaderBoard of the game at a given stage of the game - according to the instruction in the exercise document.
    *
    * @return
    *      void
    */
    void printLeaderBoard() const;
    
    /*
    *  Checks if the game ended:
    *
    *  @return
    *          True if the game ended
    *          False otherwise
    */
    bool isGameOver() const;
    
	/*
    *  Returns the number of rounds played.
    *
    *  @return
    *          int - number of rounds played
    */
    int getNumberOfRounds() const;
    ~Mtmchkin()=default;
};



#endif /* MTMCHKIN_H_ */
