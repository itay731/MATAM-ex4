#include <iostream>
#include "../Mtmchkin.h"

int main() {
    try {
        Mtmchkin newGame("deck.txt");
        while (!newGame.isGameOver()) {
            newGame.playRound();
            newGame.printLeaderBoard();
        }
    }
    catch (std::exception &e) {
        std::cout<<e.what()<<std::endl;
        throw e;
    }
    return 0;
}
