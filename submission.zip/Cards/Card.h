#ifndef EX2_Card_H
#define EX2_Card_H

#include <string>
#include "../Players/Player.h"
#include "../utilities.h"
#include <string>

class Card {
    std::string m_nameOfCard;
public:
    explicit Card(std::string name);
    Card(const Card& other) = default;
    Card& operator=(const Card& other) = default;
    //Returns the name of the card (type of the card).
    std::string getCard();
    //If adding new card type must override the function.
    virtual void applyEncounter(Player& player)=0;
    //override method that apply encounter for gang members
    //only battle cards have implementation
    virtual bool applyGang(Player& player, bool isLostAlready);
    //override method that add gang members to vector of gang
    //only gang have implementation
    virtual void addMember(std::unique_ptr<Card> newMember);
    friend std::ostream& operator<<(std::ostream& os,Card& card);
    virtual ~Card() = default;
};


#endif //EX2_Card_H
