#include "Pitfall.h"

using namespace std;

Pitfall::Pitfall(): Card("Pitfall")
{}

void Pitfall::applyEncounter(Player &player)
{
    if(player.getType()!="Rogue"){
        printPitfallMessage(false);
        player.damage(REDUCE_LIFE_PITFALL);
    }
    else{
        printPitfallMessage(true);
    }
}
