#ifndef HW4_DRAGON_H
#define HW4_DRAGON_H

#include "../Players/Player.h"
#include "Card.h"

static const int DRAGON_FORCE=25;
static const int DRAGON_LOT=1000;

class Dragon: public Card
{
public:
    explicit Dragon();
    Dragon(const Dragon& dragon) = default;
    Dragon& operator=(const Dragon& other) = default;
    //Overriding encounter of Dragon card.
    void applyEncounter(Player& player) override;
    bool applyGang(Player& player, bool isLostAlready) override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Dragon() override {};

};
#endif //HW4_DRAGON_H

