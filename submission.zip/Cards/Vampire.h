#ifndef HW4_VAMPIRE_H
#define HW4_VAMPIRE_H

#include "../Players/Player.h"
#include "Card.h"

static const int VAMPIRE_FORCE=10;
static const int VAMPIRE_LOT=2;
static const int VAMPIRE_DAMAGE=10;
static const int VAMPIRE_LOST_FORCE=-1;

class Vampire: public Card
{
public:
    explicit Vampire();
    Vampire(const Vampire& vampire) = default;
    Vampire& operator=(const Vampire& other) = default;
    //Overriding encounter of Vampire card.
    void applyEncounter(Player& player) override;
    bool applyGang(Player& player, bool isLostAlready);
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Vampire() override {};
};
#endif //HW4_VAMPIRE_H
