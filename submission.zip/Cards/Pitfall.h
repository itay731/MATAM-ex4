#ifndef HW4_PITFALL_H
#define HW4_PITFALL_H

#include "../Players/Player.h"
#include "Card.h"

static const int REDUCE_LIFE_PITFALL=10;

class Pitfall: public Card
{
public:
    explicit Pitfall();
    Pitfall(const Pitfall& pitfall) = default;
    Pitfall& operator=(const Pitfall& other) = default;
    //Overriding encounter of Pitfall card.
    void applyEncounter(Player& player) override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Pitfall() override {};
};
#endif //HW4_PITFALL_H
