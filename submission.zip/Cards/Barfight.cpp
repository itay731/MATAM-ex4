#include "Barfight.h"

using namespace std;

Barfight::Barfight() : Card("Barfight")
{}

void Barfight::applyEncounter(Player &player)
{
    if(player.getType()!="Fighter"){
        printBarfightMessage(false);
        player.damage(REDUCE_LIFE_BARFIGHT);
    }
    else{
        printBarfightMessage(true);
    }
}


