#include "Vampire.h"

using namespace std;

Vampire::Vampire(): Card("Vampire")
{}

void Vampire::applyEncounter(Player &player)
{
    if(player.getAttackStrength()<VAMPIRE_FORCE){
        player.damage(VAMPIRE_DAMAGE);
        player.buff(VAMPIRE_LOST_FORCE);
        printLossBattle(player.getName(),this->getCard());
    }
    else
    {
        player.addCoins(VAMPIRE_LOT);
        player.levelUp();
        printWinBattle(player.getName(),this->getCard());
    }
}

bool Vampire::applyGang(Player &player, bool isLostAlready)
{
    if(player.getAttackStrength()<VAMPIRE_FORCE || isLostAlready){
        player.damage(VAMPIRE_DAMAGE);
        player.buff(VAMPIRE_LOST_FORCE);
        printLossBattle(player.getName(),this->getCard());
        return true;
    }
    else
    {
        player.addCoins(VAMPIRE_LOT);
        return false;
    }
}

