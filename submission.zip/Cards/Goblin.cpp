#include "Goblin.h"

using namespace std;

Goblin::Goblin(): Card("Goblin")
{}

void Goblin::applyEncounter(Player &player)
{
    if(player.getAttackStrength()<GOBLIN_FORCE){
        player.damage(GOBLIN_DAMAGE);
        printLossBattle(player.getName(),this->getCard());
    }
    else{
        player.levelUp();
        player.addCoins(GOBLIN_LOT);
        printWinBattle(player.getName(),this->getCard());
    }
}

bool Goblin::applyGang(Player &player, bool isLostAlready)
{
    if(player.getAttackStrength()<GOBLIN_FORCE || isLostAlready){
        player.damage(GOBLIN_DAMAGE);
        printLossBattle(player.getName(),this->getCard());
        return true;
    }
    else{
        player.addCoins(GOBLIN_LOT);
        return false;
    }
}


