#ifndef HW4_BARFIGHT_H
#define HW4_BARFIGHT_H

#include "../Players/Player.h"
#include "Card.h"

const int static REDUCE_LIFE_BARFIGHT=10;

class Barfight: public Card
{
public:
    explicit Barfight();
    Barfight(const Barfight& barfight) = default;
    Barfight& operator=(const Barfight& other) = default;
    //Overriding encounter of Barfight card.
    void applyEncounter(Player& player) override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Barfight() override {};
};
#endif //HW4_BARFIGHT_H
