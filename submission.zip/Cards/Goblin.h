#ifndef HW4_GOBLIN_H
#define HW4_GOBLIN_H

#include "../Players/Player.h"
#include "Card.h"

static const int GOBLIN_FORCE=6;
static const int GOBLIN_LOT=2;
static const int GOBLIN_DAMAGE=10;

class Goblin: public Card
{
public:
    explicit Goblin();
    Goblin(const Goblin& goblin) = default;
    Goblin& operator=(const Goblin& other) = default;
    //Overriding encounter of Goblin card.
    void applyEncounter(Player& player) override;
    bool applyGang(Player& player, bool isLostAlready) override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Goblin() override {};

};
#endif //HW4_GOBLIN_H
