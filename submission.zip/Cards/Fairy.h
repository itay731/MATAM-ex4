#ifndef HW4_FAIRY_H
#define HW4_FAIRY_H

#include "../Players/Player.h"
#include "Card.h"

static const int ADD_LIFE=10;

class Fairy: public Card
{
public:
    explicit Fairy();
    Fairy(const Fairy& fairy) = default;
    Fairy& operator=(const Fairy& other) = default;
    //Overriding encounter of Fairy card.
    void applyEncounter(Player& player) override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Fairy() override {};
};
#endif //HW4_FAIRY_H
