#include "Card.h"
#include "Vampire.h"
#include "Goblin.h"
#include "Dragon.h"

Card::Card(std::string name) {
    m_nameOfCard=name;
}

std::string Card::getCard()
{
    return m_nameOfCard;
}

bool Card::applyGang(Player& player, bool isLostAlready)
{
    return true;
}

void Card::addMember(std::unique_ptr<Card> newMember)
{}

std::ostream& operator<<(std::ostream& os,Card& card)
{
    if(card.getCard()=="Vampire"){
        printCardDetails(os, card.getCard());
        printMonsterDetails(os,VAMPIRE_FORCE,VAMPIRE_DAMAGE,VAMPIRE_LOT);
    }
    else if(card.getCard()=="Goblin"){
        printCardDetails(os, card.getCard());
        printMonsterDetails(os ,GOBLIN_FORCE,GOBLIN_DAMAGE,GOBLIN_LOT);
    }
    else if(card.getCard()=="Dragon"){
        printCardDetails(os, card.getCard());
        printMonsterDetails(os,DRAGON_FORCE,DRAGON_FORCE,DRAGON_LOT,true);
    }
//#todo:olay
    else if(card.getCard()=="Gang"){
        os<<"You encountered a gang of monsters!";
    }
    else {
        printCardDetails(os, card.getCard());
    }
    printEndOfCardDetails(os);
    return os;
}

