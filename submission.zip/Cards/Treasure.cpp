#include "Treasure.h"

using namespace std;

Treasure::Treasure(): Card("Treasure")
{}

void Treasure::applyEncounter(Player &player)
{
    player.addCoins(EXTRA_COINS);
    printTreasureMessage();
}


