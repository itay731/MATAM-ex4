#ifndef HW4_TREASURE_H
#define HW4_TREASURE_H

#include "../Players/Player.h"
#include "Card.h"

static const int EXTRA_COINS=10;

class Treasure: public Card
{
public:
    explicit Treasure();
    Treasure(const Treasure& goblin) = default;
    Treasure& operator=(const Treasure& other) = default;
    //Overriding encounter of Treasure card.
    void applyEncounter(Player& player) override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Treasure() override {};
};
#endif //HW4_TREASURE_H
