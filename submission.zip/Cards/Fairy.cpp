#include "Fairy.h"

using namespace std;

Fairy::Fairy(): Card("Fairy")
{}

void Fairy::applyEncounter(Player &player)
{
    if(player.getType()=="Wizard"){
        printFairyMessage(true);
        player.heal(ADD_LIFE);
    }
    else{
        printFairyMessage(false);
    }
}
