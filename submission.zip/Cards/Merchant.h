#ifndef HW4_MERCHANT_H
#define HW4_MERCHANT_H

#include "../Players/Player.h"
#include "Card.h"

static const int NO_CHANGE=0;
static const int ADD_FORCE=2;
static const int ADD_HEALTH=1;
static const int COST_HEALTH=5;
static const int COST_FORCE=10;
static const int ADD=1;

class Merchant: public Card
{
    static std::string getAction();
public:
    explicit Merchant();
    Merchant(const Merchant& merchant) = default;
    Merchant& operator=(const Merchant& other) = default;
    //Overriding encounter of Merchant card.
    void applyEncounter(Player& player) override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Merchant() override {};

};

#endif //HW4_MERCHANT_H
