#include "Dragon.h"

using namespace std;

Dragon::Dragon(): Card("Dragon")
{}

void Dragon::applyEncounter(Player &player)
{
    if(player.getAttackStrength()<DRAGON_FORCE){
        player.kill();
        printLossBattle(player.getName(),this->getCard());
    }
    else{
        player.addCoins(DRAGON_LOT);
        player.levelUp();
        printWinBattle(player.getName(),this->getCard());
    }
}

bool Dragon::applyGang(Player &player, bool isLostAlready)
{
    if(player.getAttackStrength()<DRAGON_FORCE || isLostAlready){
        player.kill();
        printLossBattle(player.getName(),this->getCard());
        return true;
    }
    else{
        player.addCoins(DRAGON_LOT);
        return false;
    }
}