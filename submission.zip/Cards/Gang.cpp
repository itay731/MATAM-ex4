#include "Gang.h"
#include "Goblin.h"
#include "Dragon.h"
#include "Vampire.h"

using namespace std;

Gang::Gang(): Card("Gang"), m_gangMembers(), m_numOfMembers(0)
{}

Gang::Gang(const Gang &gang) : Card("Gang")
{
    m_numOfMembers=0;
    for (int i = 0; i < gang.size(); ++i) {
        addMember(makeBattleCard(gang.getNameOfGangMember(i)));
    }
}

Gang& Gang::operator=(const Gang &other)
{
    if (this==&other){
        return *this;
    }
    vector<unique_ptr<Card>> tmp;
    for (int i = 0; i < other.size(); ++i) {
        tmp.push_back(makeBattleCard(other.getNameOfGangMember(i)));
    }
    m_gangMembers.clear();
    m_gangMembers=move(tmp);
    m_numOfMembers=other.size();
    return *this;
}

string Gang::getNameOfGangMember(int index) const
{
    return m_gangMembers[index]->getCard();
}

unique_ptr<Card> Gang::makeBattleCard(const std::string& name)
{
    try {
        if (name == "Goblin") {
            return (unique_ptr<Card>(new Goblin()));
        } else if (name == "Vampire") {
            return (unique_ptr<Card>(new Vampire()));
        } else {
            return (unique_ptr<Card>(new Dragon()));
        }
    }
    catch (bad_alloc &e) {
        throw e;
    }
}

int Gang::size() const
{
    return m_numOfMembers;
}

void Gang::addMember(unique_ptr<Card> newMember)
{
    m_gangMembers.push_back(move(newMember));
    m_numOfMembers++;
}

void Gang::applyEncounter(Player &player)
{
    bool isLost = false;
    for (int i = 0; i < m_numOfMembers; ++i) {
        isLost = m_gangMembers[i]->applyGang(player, isLost);
    }
    if(!isLost||m_numOfMembers==0){
        printWinBattle(player.getName(),"Gang");
        player.levelUp();
    }
}