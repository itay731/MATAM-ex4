#include "Merchant.h"
#include "../Mtmchkin.h"
#include <fstream>

using namespace std;

Merchant::Merchant(): Card("Merchant")
{}

string Merchant::getAction()
{
    bool flagOfAction = false;
    string input;
    while (!flagOfAction) {
        getline(cin,input,'\n');
        if (input == "0" || input == "1" || input == "2") {
            flagOfAction = true;
        }
        else {
            printInvalidInput();
        }
    }
    return input;
}

void Merchant::applyEncounter(Player &player)
{
    printMerchantInitialMessageForInteractiveEncounter(cout,player.getName(),player.getCoins());
    string input=getAction();
    //getAction make sure input is "0"/"1"/"2", so stoi cant broke.
    int whatToDO=stoi(input);
    if(whatToDO==ADD_FORCE){
        if(player.getCoins()>=COST_FORCE)
        {
            player.pay(COST_FORCE);
            player.buff(ADD);
            printMerchantSummary(cout,player.getName(),whatToDO,COST_FORCE);
        }
        else{
            printMerchantInsufficientCoins(cout);
            printMerchantSummary(cout,player.getName(),whatToDO,NO_CHANGE);
        }
    }
    else if(whatToDO==ADD_HEALTH){
        if(player.getCoins()>=COST_HEALTH){
            player.pay(COST_HEALTH);
            player.heal(ADD);
            printMerchantSummary(cout,player.getName(),whatToDO,COST_HEALTH);
        }
        else{
            printMerchantInsufficientCoins(cout);
            printMerchantSummary(cout,player.getName(),whatToDO,NO_CHANGE);
        }

    }
    else{
        printMerchantSummary(cout,player.getName(),whatToDO,NO_CHANGE);
    }
}
