#ifndef HW4_GANG_H
#define HW4_GANG_H

#include "Card.h"
#include <iostream>
#include <vector>
#include "../Players/Player.h"

class Gang: public Card
{
    std::vector<std::unique_ptr<Card>> m_gangMembers;
    int m_numOfMembers;
    std::string getNameOfGangMember(int index) const;
    int size()const;
    //Making battle card (we take for granted that the name is name of battle card).
    static std::unique_ptr<Card> makeBattleCard(const std::string& name);
public:
    explicit Gang();
    Gang(const Gang& gang);
    Gang& operator=(const Gang& other);
    void addMember(std::unique_ptr<Card> newMember) override;
    //Overriding encounter of Gang card.
    void applyEncounter(Player& player) override;
    //D'tor is empty to make sure we are using the D'tor of base class.
    ~Gang() override {};
};

#endif //HW4_GANG_H


